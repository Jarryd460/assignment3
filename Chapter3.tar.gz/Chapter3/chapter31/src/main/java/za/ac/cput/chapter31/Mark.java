package za.ac.cput.chapter31;

/**
 * Created by student on 2015/02/19.
 */
public class Mark {

    private int mark;

    public Mark() {

    }

    public Mark(int mark) {
        this.mark = mark;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }
}
