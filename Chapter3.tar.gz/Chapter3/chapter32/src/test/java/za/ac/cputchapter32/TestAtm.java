package za.ac.cputchapter32;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import za.ac.cputchapter32.atm.Atm;
import za.ac.cputchapter32.atm.AtmMachine;
import za.ac.cputchapter32.customer.Person;

/**
 * Created by student on 2015/02/20.
 */
public class TestAtm {

    Person person;
    AtmMachine atm;

    @Before
    public void initialize() {

        atm = new Atm();
        person = new Person("1234567890", "Jarryd", "Deane", "0987123456", "12 Area Street", 10000);
    }

    @Test
    public void deposit() {

        Assert.assertEquals(10500, atm.deposit(person.getBalance(), 500), 0.0f);
    }

    @Test
    public void withdraw() {

        Assert.assertEquals(10000, atm.withdraw(person.getBalance(), 500), 0.0f);
    }
}
