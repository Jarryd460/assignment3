package za.ac.cputchapter32.atm;

/**
 * Created by student on 2015/02/20.
 */
public class Atm implements AtmMachine{

    public double deposit(double bal,double amt) {

        return bal + amt;
    }

    public double withdraw(double bal,double amt) {
        if(bal < amt) {

            return bal - amt;
        }
        return bal;
    }
}
