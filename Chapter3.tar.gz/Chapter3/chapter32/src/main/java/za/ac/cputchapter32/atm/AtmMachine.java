package za.ac.cputchapter32.atm;

/**
 * Created by student on 2015/02/20.
 */
public interface AtmMachine {

    public abstract double deposit(double bal,double amt);
    public abstract double withdraw(double bal,double amt);
}
