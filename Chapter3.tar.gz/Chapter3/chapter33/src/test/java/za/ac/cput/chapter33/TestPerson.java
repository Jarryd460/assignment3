package za.ac.cput.chapter33;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import za.ac.cput.chapter33.customer.Person;

/**
 * Created by student on 2015/02/20.
 */
public class TestPerson {

    Person person;

    @Before
    public void initialize() {

        person = new Person();
    }

    @Test
    public void accountNumber() {

        person.setAccountNumber("1234567890");
        Assert.assertEquals("1234567890", person.getAccountNumber());
    }

    @Test
    public void firstName() {

        person.setFirstName("Jarryd");
        Assert.assertEquals("Jarryd", person.getFirstName());
    }

    @Test
    public void lastName() {

        person.setLastName("Deane");
        Assert.assertEquals("Deane", person.getLastName());
    }

    @Test
    public void phoneNumber() {

        person.setPhoneNumber("0987123456");
        Assert.assertEquals("0987123456", person.getPhoneNumber());
    }

    @Test
    public void address() {

        person.setAddress("12 Area Street");
        Assert.assertEquals("12 Area Street", person.getAddress());
    }

    @Test
    public void balance() {

        person.setBalance(10000);
        Assert.assertEquals(10000, person.getBalance(), 0.0f);
    }
}
