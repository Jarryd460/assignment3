package za.ac.cput.chapter33;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import za.ac.cput.chapter33.atm.Atm;
import za.ac.cput.chapter33.atm.AtmMachine;
import za.ac.cput.chapter33.config.Config;
import za.ac.cput.chapter33.customer.Person;


/**
 * Created by student on 2015/02/20.
 */
public class TestAtm {

    Person person;
    AtmMachine atmMachine;

    @Before
    public void setUp() throws Exception {


    }

    @Before
    public void initialize() {

        ApplicationContext ctx = new AnnotationConfigApplicationContext(Config.class);
        atmMachine = (AtmMachine)ctx.getBean("myatm");
        //atm = new Atm();
        person = new Person("1234567890", "Jarryd", "Deane", "0987123456", "12 Area Street", 10000);
    }

    @Test
    public void deposit() {

        Assert.assertEquals(10500, atmMachine.deposit(person.getBalance(), 500), 0.0f);
    }

    @Test
    public void withdraw() {

        Assert.assertEquals(10000, atmMachine.withdraw(person.getBalance(), 500), 0.0f);
    }
}
