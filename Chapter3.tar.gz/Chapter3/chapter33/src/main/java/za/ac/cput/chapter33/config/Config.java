package za.ac.cput.chapter33.config;

import org.springframework.context.annotation.Bean;
import za.ac.cput.chapter33.atm.Atm;
import za.ac.cput.chapter33.atm.AtmMachine;

/**
 * Created by student on 2015/02/20.
 */
public class Config {

    @Bean(name="myatm")
    public AtmMachine getService()
    {
        return new Atm();
    }
}
